
			     osFree binary snapshot
			        December 5, 2002
			         www.osfree.org


1. General status

   This release is not  intended for production use. Its  goal is to conclude
   the work being  made on the open-source osFree  project.  The released set
   comprises    several    command-line    utilities,  requiring  a   working
   OS/2-compatible system.

   The files  have been built for OS/2 LIBC library (LIBCS.DLL), therefore, a
   LIBC-capable environment is  required. In Warp 3, LIBC is introduced  with
   fixpak XR_W032. It is prepackaged with all subsequent versions of OS/2.

   It  should be noted   that no component  has  been subjected to  extensive
   testing  yet, so the components may  only be *deemed* complete because the
   required functionality is implemented.


2. Contents of the package

   OS/2 components:

   ANSI.EXE	Complete. 
   ATTRIB.EXE	Complete. 
   CHKDSK.EXE	See Note 1. 
   EJECT.EXE	Complete. 
   FORMAT.EXE	See Note 1. 
   LABEL.EXE	See Note 1. 
   RECOVER.EXE	See Note 1. 
   SYSINSTX.EXE	See Note 1. 
   TREE.EXE	Complete, see Note 3. 

   CMD.EXE components:

   CLS.EXE	Complete. 
   MKDIR.EXE	Complete. 
   VER.EXE	See Note 2. 
   VOL.EXE	Complete. 

Notes: 

 1. The current implementation of  file system  utilities (CHKDSK, FORMAT,
    etc.)  forwards to the  corresponding service DLLs of installable file
    systems (such as UHPFS.DLL).  Consequently, certain operations are not
    supported on FAT12/FAT16 file systems.

 2. Revision  level  is displayed  as  "0.0", since none  of the  existing
    OS/2  kernel  environments  supplies  revision  level  information  to
    user-mode processes.

 3. TREE.EXE   has been enhanced  to allow   directory  name as   an input
    argument. In this   case, the  display  is  limited   to a  particular
    branch.


3. CMD.EXE

   A proposed design for CMD.EXE  relies on a  common library and independent
   command  handlers. Its  existing implementation  is provided  in a set  of
   tools listed above in the "CMD" group.

   Several  commands, such   as SET, are   to  be incorporated   into CMD.EXE
   core. In the source code they reside in "cmd\cmd" group.


4. Future enhancements

   A "sanity check"  script to test  the behavior of utilities is considered.
   Whenever there is a commonality across OS/2, DOS and Win32 tools, the same
   behavior should be extended to the osFree code.

   The  current  implementation uses   IBM's  LIBC.  For a  truly open-source
   environment, a replacement  LIBC library must be  created. The source code
   of osFree  toolset is adapted to  both IBM LIBC and Watcom 11.0/OpenWatcom
   libraries.


5. Source code

   In order to recompile  the released source code,  one would need  the OS/2
   toolkit and a Watcom C  compiler. The released  set has been compiled with
   Watcom C v 11.0c. 

   To compile, change into the source code directory, then type:
        wmake config
        wmake

   Having the toolkit   LIBC configured for   OMF,  one may   also supply the
   LIBC headers path to "wmake config":
        wmake config LIBC=X:\OS2TK45\H\LIBC

   In    the latter case, the  executable    files will be linked dynamically
   against IBM LIBC, as the distribution set is.


6. Contacting the development team

   A web site dedicated to the development is at www.osfree.org.

   To join a public discussion forum, please sign up at:
   http://groups.yahoo.com/group/osfree

   FTP site: ftp://jma.dnsalias.com/osfree
   FTP write-only "drop zone": ftp://jma.dnsalias.com/osfree/dropzone

   Anonymous read-only CVS: :pserver:osfree@jma.dnsalias.com:d:/project
   Password is "readonly".
