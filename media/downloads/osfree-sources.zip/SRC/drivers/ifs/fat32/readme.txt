Place for FAT32 driver from http://fat32.netlabs.org
