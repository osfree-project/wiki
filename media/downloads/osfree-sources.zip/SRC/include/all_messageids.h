/*
   defines for messages identification,
   shared along all os source

   (c) osFree Project 2002, <http://www.osFree.org>
   for licence see licence.txt in root directory, or project website

   Bartosz Tomasik <bart2@asua.org.pl>
   JMA <jma@jma.se>
*/

#ifndef _ALL_MESSAGEIDS_H_
#define _ALL_MESSAGEIDS_H_

#include "mis_basemid.h"

#endif /* _ALL_MESSAGEIDS_H_ */