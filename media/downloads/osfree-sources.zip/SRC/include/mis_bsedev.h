#define DSK_UNLOCKEJECTMEDIA               0X0040
