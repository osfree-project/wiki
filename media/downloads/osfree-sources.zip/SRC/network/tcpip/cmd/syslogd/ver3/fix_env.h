char *fix_env(char *, char *);
