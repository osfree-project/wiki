Place for FreePM project (http://frepm.sourceforge.net)
