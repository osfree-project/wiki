Place for NewView project
