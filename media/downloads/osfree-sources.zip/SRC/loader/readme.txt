FreeLoader project (http://www.edm2.com)
