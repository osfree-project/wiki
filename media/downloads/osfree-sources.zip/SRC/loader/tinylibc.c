#include <stdarg.h>


void putdec(unsigned int byte)
{
  unsigned char b1;
  int b[30];
  signed int nb;
  int i=0;

  while(1){
    b1=byte%10;
    b[i]=b1;
    nb=byte/10;
    if(nb<=0){
      break;
    }
    i++;
    byte=nb;
  }

  for(nb=i+1;nb>0;nb--){
    puthexd(b[nb-1]);
  }
}

void puthexi(unsigned int dword)
{
  puthex( (dword & 0xFF000000) >>24);
  puthex( (dword & 0x00FF0000) >>16);
  puthex( (dword & 0x0000FF00) >>8);
  puthex( (dword & 0x000000FF));
}


void puthex(unsigned char byte)
{
 unsigned  char lb, rb;

  lb=byte >> 4;

  rb=byte & 0x0F;


  puthexd(lb);
  puthexd(rb);
}

void puthexd(unsigned char digit)
{
  char table[]="0123456789ABCDEF";
   putchar(table[digit]);
}



void printf(const char *fmt, ...)
{
  va_list args;
  va_start(args, fmt);

  textcolor(7);

  vprintf(fmt, args);

  va_end(args);
}

void vprintf(const char *fmt, va_list args)
{
  while (*fmt) {

    switch (*fmt) {
    case '%':
      fmt++;

      switch (*fmt) {
      case 's':
        puts(va_arg(args, char *));
        break;

      case 'c':
        putchar(va_arg(args, unsigned int));
        break;

      case 'i':
        putdec(va_arg(args, unsigned int));
        break;

      case 'x':
        puthex(va_arg(args, unsigned int));
        break;

      case 'X':
        puthexi(va_arg(args, unsigned int));
        break;

      case 'z':
        textcolor(va_arg(args,unsigned int));
        break;

      }


      break;

    default:
      putchar(*fmt);
      break;
    }

    fmt++;
  }
}