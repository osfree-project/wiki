struct SREGS {
        unsigned short es, cs, ss, ds;
        unsigned short fs, gs;
};

void DispNTS(char far * CMsgBuff); external;
void Debug(char far * CMsgBuff); external;
