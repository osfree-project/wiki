/*
 $Header: /netlabs.cvs/osfree/src/nonos2/utlapi/pm.h,v 1.1.1.1 2003/10/04 08:27:38 prokushev Exp $
*/


#ifdef INCL_WINRECTANGLES
#include "pm/winrectangles.h"
#endif