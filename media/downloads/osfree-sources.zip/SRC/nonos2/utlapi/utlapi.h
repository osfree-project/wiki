/*
 $Header: /netlabs.cvs/osfree/src/nonos2/utlapi/utlapi.h,v 1.1.1.1 2003/10/04 08:27:38 prokushev Exp $
*/


#ifdef INCL_LIBRECTANGLES
#include "utlapi/librectangles.h"
#endif