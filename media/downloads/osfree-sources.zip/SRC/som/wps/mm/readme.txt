Place for CWMM project (if will be opensource)
