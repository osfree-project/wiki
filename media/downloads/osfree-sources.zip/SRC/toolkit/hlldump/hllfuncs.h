

/* exe.c */
BOOL ProcessLx();

/* hll.c */
void HllLoadFile(PSZ szFileName);

/* hlldirectory.c */
BOOL ProcessDirectory();

/* hllmodule.c */
BOOL ProcessModules();

/* hllpublics.c */
BOOL ProcessPublics();

/* hlllines.c */
BOOL ProcessLines();

/* hllsymbols.c */
BOOL ProcessSymbols();


/* hlltypes.c */
BOOL ProcessTypes();
