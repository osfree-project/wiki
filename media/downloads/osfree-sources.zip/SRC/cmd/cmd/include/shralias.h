// Text strings for shared memory and SHRALIAS sentinels
// Copyright 1996  Rex C. Conn and JP Software Inc.  All rights reserved

#define SHR_4OS2_ALIAS "\\SHAREMEM\\JP4OS2_A"
#define SHR_4OS2_HISTORY "\\SHAREMEM\\JP4OS2_H"
#define SHR_4OS2_DIRHIST "\\SHAREMEM\\JP4OS2_D"
#define SHR_4OS2_SENTINEL "\\SEM32\\SHRALIAS\\SENTINEL.32"

