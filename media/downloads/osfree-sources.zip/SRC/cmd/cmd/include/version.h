// Version info

#include "build.h"

#if _PM != 0
#define VER_MAJOR 2
#define VER_MINOR 03
#define VER_REVISION "B"

#else
#define VER_MAJOR 3
#define VER_MINOR 04
#define VER_REVISION "B"

#endif

