// PRODUCT.H - Create defines for 4xxx / TCMD family products

#ifndef __WATCOMC__
#define __WATCOMC__ 0
#endif

//#ifdef __4OS2
#define _OS2 32
#define _HPFS 1
#define _DOS 0
#define _WIN 0
#define _NT 0
#define _PM 0
//#endif

