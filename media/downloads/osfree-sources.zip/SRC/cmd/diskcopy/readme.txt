Place for dskcpy1 tool from http://os2tools.netlabs.org
