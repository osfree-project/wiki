Regina-REXX project (http://regina-rexx.sourceforge.net)
