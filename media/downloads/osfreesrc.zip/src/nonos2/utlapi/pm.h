/*
 $Header: d:/project/osfree/src/nonos2/utlapi/pm.h,v 1.1.1.1 2002/04/05 20:14:18 osfree Exp $
*/


#ifdef INCL_WINRECTANGLES
#include "pm/winrectangles.h"
#endif