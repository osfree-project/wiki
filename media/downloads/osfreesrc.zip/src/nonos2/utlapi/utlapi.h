/*
 $Header: d:/project/osfree/src/nonos2/utlapi/utlapi.h,v 1.1.1.1 2002/04/05 20:14:18 osfree Exp $
*/


#ifdef INCL_LIBRECTANGLES
#include "utlapi/librectangles.h"
#endif